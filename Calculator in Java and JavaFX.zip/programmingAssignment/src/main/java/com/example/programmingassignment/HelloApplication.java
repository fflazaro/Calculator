////
// Name: Franchesca Lazaro
// Program Name: Programming Assignment GUI Edition
//
// Description: I made a calculator that utilizes 4 operations plus a bonus operation - *, /, +, -, %
// The calculator has a background that fades in and out and it has my initials dancing horizontally on the screen
// The code for the parentheses and the decimal are also blank but I still added them for design and they still are displayed in the textfield!
// I used a vbox for the general layout and a tilepane for the buttons. Then I put both of them in a group.
// For the calculator class, I used a switch case to identify the operator being used.
////

package com.example.programmingassignment;

import javafx.animation.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Bounds;
import javafx.geometry.Orientation;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextBoundsType;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

public class HelloApplication extends Application {
    boolean onSecondNum = false;
    double firstNum = 0;
    double secondNum = 0;
    double result;
    char operator;
    String expression = "";

    @Override
    public void start(Stage stage) throws IOException {
        //Made an instance of my calculator class
        Calculator calc = new Calculator();

        Group root = new Group();
        Scene scene = new Scene(root, 262, 140);

        //This rectangle serves as the background for the calculator
        Rectangle rect = new Rectangle();
        rect.setWidth(262);
        rect.setHeight(157);
        rect.setFill(Color.web("22223B", 1.0));

        Pane canvas = new Pane();

        //Initials
        Text initials = new Text("FL");
        initials.setFill(Color.web("C9ADA7", 1.0));
        //initials.relocate(400, 300);
        initials.setBoundsType(TextBoundsType.VISUAL);
        canvas.getChildren().addAll(initials);

        //Code for initials to "dance"
//        final Timeline timeline = new Timeline();
//        timeline.setCycleCount(Animation.INDEFINITE);
//        timeline.setAutoReverse(true);
////        timeline.getKeyFrames().add(new KeyFrame (Duration.millis(1500),
////                new KeyValue(initials.translateXProperty(), Math.floor(Math.random() * 210))));
//        timeline.getKeyFrames().add(new KeyFrame (Duration.millis(1500),
//                new KeyValue(initials.translateXProperty(), 262)));
//        timeline.play();

        //Animation for the background
        FadeTransition ft = new FadeTransition(Duration.millis(2000), rect);
        ft.setFromValue(1.0);
        ft.setToValue(0.80);
        ft.setAutoReverse(true);
        ft.setCycleCount(Animation.INDEFINITE);
        ft.play();


//        final Timeline loop = new Timeline(new KeyFrame(Duration.millis(15), new EventHandler<ActionEvent>() {
//            double deltaX = 1;
//            double deltaY = 1.5;
//            @Override
//            public void handle(ActionEvent actionEvent) {
//                initials.setLayoutX(initials.getLayoutY() + deltaX);
//                initials.setLayoutY(initials.getLayoutY() + deltaY);
//                final Bounds bounds = initials.getLayoutBounds();
//                final boolean atRightBorder = initials.getLayoutX() >= (scene.getWidth() - bounds.getWidth() + 15) ;
//                final boolean atLeftBorder = initials.getLayoutX() <= 0;
//                final boolean atBottomBorder = initials.getLayoutY() >= (scene.getHeight() - bounds.getHeight() + 15);
//                final boolean atTopBorder = initials.getLayoutY() <= 0;
//                if (atRightBorder || atLeftBorder) {
//                    deltaX *= -1;
//                }
//                if (atBottomBorder || atTopBorder) {
//                    deltaY *= -1;
//                }
//            }
//        }));
//        loop.setCycleCount(Timeline.INDEFINITE);
//        loop.play();

        //8+3*2
        //MDAS - multiplication, divison, addition, subtraction
        final Timeline loop = new Timeline(new KeyFrame(Duration.millis(10), new EventHandler<ActionEvent>() {
            //speed of text
            double deltaX = 3;
            double deltaY = 3;

            @Override
            public void handle(final ActionEvent t) {
                //actual movement
                initials.setLayoutX(initials.getLayoutX() + deltaX);
                initials.setLayoutY(initials.getLayoutY() + deltaY);

                //bounds
                final Bounds bounds = canvas.getBoundsInLocal();
                //border booleans
                final boolean atRightBorder = initials.getLayoutX() >= (bounds.getMaxX() - initials.getLayoutBounds().getMaxX()) ;
                final boolean atLeftBorder = initials.getLayoutX() <= initials.getLayoutBounds().getMinX();
                final boolean atBottomBorder = initials.getLayoutY() >= (bounds.getMaxY() - initials.getLayoutBounds().getMaxY());
                final boolean atTopBorder = initials.getLayoutY() <= initials.getLayoutBounds().getMinY() * -1;
                //border logic
                if (atRightBorder || atLeftBorder) {
                    deltaX *= -1;
                }
                if (atBottomBorder || atTopBorder) {
                    deltaY *= -1;
                }
            }
        }));
        loop.setCycleCount(Timeline.INDEFINITE);
        loop.play();


        //Textfield for the output
        TextField output = new TextField();
        output.setStyle("-fx-text-fill: #4A4E69; ");
        //output.setPromptText("Only supports single digit numbers");

        //Vbox to stack everything
        VBox vBox = new VBox();
        //Tilepane for the buttons
        TilePane tile = new TilePane();

        //Button creation
        Button b1 = new Button(" 1 ");
        Button b2 = new Button(" 2 ");
        Button b3 = new Button(" 3 ");
        Button plus = new Button(" + ");
        Button mod = new Button(" % ");
        Button b4 = new Button("4");
        Button b5 = new Button("5");
        Button b6 = new Button("6");
        Button minus = new Button("-");
        Button leftparenth = new Button("(");
        Button b7 = new Button("7");
        Button b8 = new Button("8");
        Button b9 = new Button("9");
        Button divison = new Button("/");
        Button rightparenth = new Button(")");
        Button clear = new Button("C");
        Button b0 = new Button("0");
        Button equals = new Button("=");
        Button multiplication = new Button("*");
        Button decimal = new Button(".");

        //Button sizes
        b1.setPrefSize(50, 20);
        b2.setPrefSize(50, 20);
        b3.setPrefSize(50, 20);
        plus.setPrefSize(50, 20);
        mod.setPrefSize(50, 20);
        b4.setPrefSize(50, 20);
        b5.setPrefSize(50, 20);
        b6.setPrefSize(50, 20);
        minus.setPrefSize(50, 20);
        leftparenth.setPrefSize(50, 20);
        b7.setPrefSize(50, 20);
        b8.setPrefSize(50, 20);
        b9.setPrefSize(50, 20);
        divison.setPrefSize(50, 20);
        rightparenth.setPrefSize(50, 20);
        clear.setPrefSize(50, 20);
        b0.setPrefSize(50, 20);
        equals.setPrefSize(50, 20);
        multiplication.setPrefSize(50, 20);
        decimal.setPrefSize(50, 20);

        //Button background color
        b1.setStyle("-fx-background-color: #9A8C98; ");
        b2.setStyle("-fx-background-color: #9A8C98; ");
        b3.setStyle("-fx-background-color: #9A8C98; ");
        plus.setStyle("-fx-background-color: #9A8C98; ");
        mod.setStyle("-fx-background-color: #9A8C98; ");
        b4.setStyle("-fx-background-color: #9A8C98; ");
        b5.setStyle("-fx-background-color: #9A8C98; ");
        b6.setStyle("-fx-background-color: #9A8C98; ");
        minus.setStyle("-fx-background-color: #9A8C98; ");
        leftparenth.setStyle("-fx-background-color: #9A8C98; ");
        b7.setStyle("-fx-background-color: #9A8C98; ");
        b8.setStyle("-fx-background-color: #9A8C98; ");
        b9.setStyle("-fx-background-color: #9A8C98; ");
        divison.setStyle("-fx-background-color: #9A8C98; ");
        rightparenth.setStyle("-fx-background-color: #9A8C98; ");
        clear.setStyle("-fx-background-color: #9A8C98; ");
        b0.setStyle("-fx-background-color: #9A8C98; ");
        equals.setStyle("-fx-background-color: #9A8C98; ");
        multiplication.setStyle("-fx-background-color: #9A8C98; ");
        decimal.setStyle("-fx-background-color: #9A8C98; ");

        tile.getChildren().addAll(b1, b2, b3, plus, mod, b4, b5, b6, minus, leftparenth, b7, b8, b9, divison, rightparenth,
                clear, b0, equals, multiplication, decimal);

        //What happens when you press a button
        b1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
//                if (onSecondNum == false){
//                    calc.setNum(1);
//                    firstNum = calc.getNum();
//                    output.setText("1");
//                } else if (onSecondNum == true){
//                    calc.setNum2(1);
//                    secondNum = calc.getNum2();
//                    output.setText("1");
//                }
                expression = expression.concat("1");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("2");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("3");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("4");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("5");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("6");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b7.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("7");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b8.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("8");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        b9.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("9");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        //?
        b0.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat("0");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        plus.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
//                if (onSecondNum == false){
//                    calc.setOperator('+');
//                    //output.setText(firstNum + "+");
//                    output.setText("+");
//                    onSecondNum = true;
//                }
                expression = expression.concat(" + ");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        mod.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat(" % ");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        minus.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat(" - ");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        divison.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat(" / ");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        multiplication.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                expression = expression.concat(" * ");
                calc.setExpression(expression);
                output.setText(expression);
            }
        });

        equals.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
//                result = calc.operateNum(firstNum, secondNum);
//                output.setText("=" + result);
                calc.parseExpression();
                calc.operateNum();
                result = calc.getResult();
                output.setText("=" + result);
            }
        });

        decimal.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                output.setText(".");
            }
        });

        leftparenth.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

            }
        });

        rightparenth.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

            }
        });

        clear.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
//                firstNum = 0;
//                secondNum = 0;
//                onSecondNum = false;
//                output.setText("");
                calc.clear();
                expression = "";
                output.setText(expression);
            }
        });


//        Button b = null;
//        for(int i = 1; i <= 16; i++){
//            b = new Button("  " + i + "  ");
//            b.setPrefSize(50, 20);
//            b.setStyle("-fx-background-color: #8A6552; ");
//            tile.getChildren().add(b);
//        }

        //Tilepane and vbox formatting
        tile.setOrientation(Orientation.HORIZONTAL);
        tile.setVgap(3);
        tile.setHgap(3);
        tile.setPrefColumns(5);
        tile.setPrefRows(3);
        tile.setPrefTileHeight(25);
        tile.setPrefTileWidth(50);
        vBox.setSpacing(3);

        //vBox.getChildren().addAll(initials, output,tile);
        //vBox.getChildren().addAll(output,tile);
        vBox.getChildren().addAll(output,tile);
        root.getChildren().addAll(rect, canvas, vBox);
        //root.getChildren().addAll(rect, canvas);
        stage.setTitle("Calculator");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}