package com.example.programmingassignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class Calculator{
    double num;
    double num2;
    boolean onSecondNum = false;
    //String operator;
    double result;
    String expression = "";
    String[] expressionsList;
    ArrayList<Double> numbers = new ArrayList<Double>();
    ArrayList<String> operations = new ArrayList<String>();
    int iterateNums = 1;
    ArrayList<String> nl = new ArrayList<>();

    public void parseExpression() {
//        expressionsList = expression.split(" ");
//        for (int i = 0; i < expressionsList.length; i++) {
//            if (i % 2 == 0 && onSecondNum == false){
//                num = Double.parseDouble(expressionsList[i]);
//
//            } else if (i % 2 == 0 && onSecondNum == true){
//                num2 = Double.parseDouble(expressionsList[i]);
//
//            } else if (i % 2 != 0 && onSecondNum == false){
//                operator = expressionsList[i];
//                onSecondNum = true;
//            }
//        }
        expressionsList = expression.split(" ");
//        for (int i =0 ;i<expressionsList.length; i++){
//
//            if(expressionsList[i].equalsIgnoreCase("*")){
//                nl.add("" + Double.parseDouble(expressionsList[i-1]) * Double.parseDouble(expressionsList[i+1]));
//            }else if(expressionsList[i].equalsIgnoreCase("/")){
//                nl.add("" + Double.parseDouble(expressionsList[i-1]) / Double.parseDouble(expressionsList[i+1]));
//            }else if(expressionsList[i].equalsIgnoreCase("+") ) {
//                if (i >= 2 && (expressionsList[i - 2].equalsIgnoreCase("*") || expressionsList[i - 2].equalsIgnoreCase("/"))){
//                    nl.add((expressionsList[i]));
//                } else{
//                    nl.add((expressionsList[i-1]));
//                    nl.add((expressionsList[i]));
//                }
//
//
//            }else if(expressionsList[i].equalsIgnoreCase("-")){
//                if (i >= 2 && (expressionsList[i - 2].equalsIgnoreCase("*") || expressionsList[i - 2].equalsIgnoreCase("/"))){
//                    nl.add((expressionsList[i]));
//                } else{
//                    nl.add((expressionsList[i-1]));
//                    nl.add((expressionsList[i]));
//                }
//            }
//        }

        for (int i =0 ;i<expressionsList.length; i++) {
            nl.add(expressionsList[i]);
            if (expressionsList[i].equalsIgnoreCase("*")) {

                nl.remove(nl.size()-1);
                nl.remove(nl.size()-1);

               nl.add("" + Double.parseDouble(expressionsList[i - 1]) * Double.parseDouble(expressionsList[i + 1]));

                i++;
            } else if (expressionsList[i].equalsIgnoreCase("/")) {
                nl.remove(nl.size()-1);
                nl.remove(nl.size()-1);

                nl.add("" + Double.parseDouble(expressionsList[i - 1]) / Double.parseDouble(expressionsList[i + 1]));

                i++;
            }else if (expressionsList[i].equalsIgnoreCase("%")) {
                nl.remove(nl.size()-1);
                nl.remove(nl.size()-1);

                nl.add("" + Double.parseDouble(expressionsList[i - 1]) % Double.parseDouble(expressionsList[i + 1]));

                i++;
            }
        }

        for (int i = 0; i < nl.size(); i++) {
            //System.out.println(nl.get(i));
            if (i % 2 == 0) {
                //num = Double.parseDouble(expressionsList[i]);
                numbers.add(Double.parseDouble(nl.get(i)));
                result = numbers.get(0);
            } else if (i % 2 != 0) {
                operations.add(nl.get(i));
            }
        }
    }

    public void clear() {
        num = 0;
        num2 = 0;
        //operator = "";
        result = 0;
        expression = "";
        Arrays.fill(expressionsList, "");
        numbers.clear();
        operations.clear();
        nl.clear();
        iterateNums = 1;

    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public double getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public double getNum2() {
        return num2;
    }

    public void setNum2(double num2) {
        this.num2 = num2;
    }

    public double getResult() {
        return result;
    }


    public void operateNum() {
//        switch (operator) {
//            case "+":
//                result += num;
//                //return result;
//                break;
//            case "-":
//                result -= num;
//                //return result;
//                break;
//            case "%":
//                result %= num;
//                //return result;
//                break;
//            case "/":
//                result /= num;
//                //return result;
//            ;
//            case "*":
//                result *= num;
//                //return result;
//                break;
//        }
        //return result;
        for (int i = 0; i < operations.size(); i++) {
            switch (operations.get(i)) {
                case "+":
                    result += numbers.get(iterateNums);
                    iterateNums++;
                    break;
                case "-":
                    result -= numbers.get(iterateNums);
                    iterateNums++;
                    break;
            }
        }


//        for (int i = 0; i < operations.size(); i++) {
//            System.out.println("Operations.get(i):" + operations.get(i) + "space");
//            String operation = operations.get(i);
//            System.out.println("Operation: " + operation);
//            if (operation == "+"){
//                System.out.println("if");
//                result += numbers.get(iterateNums);
//                iterateNums++;
//                break;
//            }
//            System.out.println("Skipped if");
//        }
    }

}
